package in.ineuron;

import java.util.Scanner;

public class case2 {
	 public static void main( String[] args )
	    {
	        Scanner sc = new Scanner(System.in);
	        
	        System.out.println("Enter the Number of your choice");
	        Integer a=sc.nextInt();
	       
	        try {
	        	 if(a < 0)
	             {
	                 throw new Exception();    
	             }
	        	 else
	        	 {
	        		 System.out.println("your number is:"+a);
	        	 }
	        }
	        catch(Exception e)
	        {
	        	System.out.println("Please enter positive number");
	        }
	     
	        
	    }
}
