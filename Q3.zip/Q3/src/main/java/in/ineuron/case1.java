package in.ineuron;

import java.util.Scanner;

/*Write a Java programme that takes an integer from the user and throws an exception
if it is negative.Demonstrate Exception handling of same program as solution.*/



//case1 
//if number is nagative throw exception
public class case1 {
	 public static void main( String[] args ) throws Exception
	    {
	        Scanner sc = new Scanner(System.in);
	        
	        System.out.println("Enter the Number of your choice");
	        Integer a=sc.nextInt();
	              
	        if(a < 0)
            {
                throw new Exception();    //throws an Exception if age is negative
            }
	        else
	        {
	        	System.out.println("your number is:"+a);
	        }
	   	     
	        
	   }
}
