package in.ineuron;

/**
2. Write a Java program to invoke parent class constructor from a child class. Create
Child class object and parent class constructor must be invoked. Demonstrate by
writing a program. Also explain key points about Constructor.
 
 */


//key points about Constructor.
/*
 * 1)Constructor is a special method which has a same name as of class name
 * class name and constructor name should be same otherwise it will behave like
 * a normal method 
 * 2)Constructor does not have return type we cannot write the
 * return statement inside the constructor 
 * 3)Contructor will not participate in
 * inheritence 
 * 4)Super method which is present inside the construtor it call the
 * parent class constructor 
 * 5)we dont have to create the object of constructor
 * it will be called automatically at the time of object creation zero
 * parametrized constructor will be called 
 * 6)constructor is used to initialized
 * the instance variable of a class
 */

//Base Class
class ParentClass {

 public ParentClass(int a, int b)
 {
     System.out.println("Parent Class Constructor");
 }
}

//Child Class
class ChildClass extends ParentClass {

 public ChildClass(int a)
 {   
     super(10, 20);
     System.out.println("Child Class Constructor");
 }
 
}

public class App 
{
    public static void main( String[] args )
    {
    	ChildClass c = new ChildClass(30);
    }
}
