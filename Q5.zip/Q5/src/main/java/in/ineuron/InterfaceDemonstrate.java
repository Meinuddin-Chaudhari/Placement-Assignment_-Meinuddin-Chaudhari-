package in.ineuron;

//key Point of interface 

/*1)interface is collection of abstract method
2)we can implement multiple interface at a time in one class
3)inside the interface we can have only abstract method pure 100% abstraction
4)Inside the interface the method are bydefault public and abstract we cannot change the access modifier like privat and protected
5)and the variable inside the interface are bydefault public static final
6)so at the time of declaration only we have to initialize the instance varible
7)we cannot write the constructor inside the interface to initialize the variable because variable are by default public static and final
8)if we are implementing the interface then we have to define all method in implementation class 
otherwise we have to make the implementation class as abstract class
*/

//interface
 interface vehiclepart {
	  void car();
	  void bike();
}

 // implementation class
class Demo1 implements vehiclepart
{

	@Override
	public void car() {
		System.out.println("From car method");
	}

	@Override
	public void bike() {
		System.out.println("From bike method");
	}
	
}
//main class
public class InterfaceDemonstrate
{
	public static void main(String args[])
	{
		Demo1 d=new Demo1();
		d.bike();
		d.car();
	}
}