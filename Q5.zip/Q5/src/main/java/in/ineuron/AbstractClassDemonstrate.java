package in.ineuron;

//key Point of Abstract class

/*
1)Abstraction means hiding the actual implementation and showing only feature
2)if we have atleast one abstract method in our class then we have to make the class as abstract class by using abstract keyword
3)In abstract class we can have both concrete method as well as abstract method
4)In abstract class we can also have constructor to initialize the instance variable
5)we cannot create the object of abstract class  and also we cannot make abstract class as final class because final class will not participate in inheritance
*/

abstract class vehicle
{
	 abstract void bike();
	 
	 public void car()
	 {
		 System.out.println("From abstract class  car Method");
	 }
	 
	 vehicle()
	 {
		 System.out.println("From abstract class constructor");
	 }
   
}

 class demo extends vehicle
{

	@Override
	void bike() {
		System.out.println("From demo class bike method");			
	}
	
}
  
public class AbstractClassDemonstrate
{
  public static void main(String args[])
   {
	 demo d=new demo();
	 d.bike();
	 d.car();
   
   }
}
