package in.ineuron;


class Runnable2 implements Runnable
{
  synchronized  public void run()
    {
        for(int i=0;i<=10;i++) 
        {
        	if (i%2==0)   
            System.out.println("Even no is :: "+i+ " from thread 2");
        }
    }
}

class Runnable1 implements Runnable
{
  synchronized  public void run()
    {
        for(int i=0;i<=10;i++) {
        	if (i%2!=0)   
            System.out.println("Odd no is :: "+i+ " from thread 1");
        }
        
    }
}


public class Mythread {

    public static void main(String[] args)
    {
        Runnable r = new Runnable1();
        Thread t = new Thread(r);
        Runnable r2 = new Runnable2();
        Thread t2 = new Thread(r2);
        t.start();
        t2.start();
    }
}