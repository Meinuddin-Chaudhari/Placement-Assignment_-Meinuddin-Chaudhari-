package in.ineuron;

import java.util.*;

import java.util.stream.*;

public class FilteredMethod {
	public static void main(String[] args){

		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(0);
		al.add(5);
		al.add(10);
		al.add(15);
		al.add(20);
		al.add(25);


		//From JDK1.8V we use Streams
		List ls=al.stream().filter(i->i%2==0).collect(Collectors.toList());
		
		ls.forEach(System.out :: println);
		
		
	}
}