package in.ineuron.shape;

public interface shape {
 double area();
 double perimeter();
}
