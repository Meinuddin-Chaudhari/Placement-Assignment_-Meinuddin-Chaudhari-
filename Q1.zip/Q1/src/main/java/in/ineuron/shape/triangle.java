package in.ineuron.shape;

public class triangle implements shape {

	private double base;
	private double height;
	private double a;
	private double b;
	private double c;

	public triangle(double base, double height,double a, double b,double c) {
		this.base = base;
		this.height = height;
		this.a=a;
		this.b=b;
		this.c=c;
	}

	@Override
	public double area() {

		return  (base * height)/2;
	}

	@Override
	public double perimeter() {

		return  (a+b+c);
	}
}

