package in.ineuron.shape;

public class circle implements shape {

	private double radius;

	public circle(double radius) {
		
		this.radius = radius;

	}

	@Override
	public double area() {

		return Math.PI * radius * radius;
	}

	@Override
	public double perimeter() {

		return 2 * Math.PI * radius;
	}
}
