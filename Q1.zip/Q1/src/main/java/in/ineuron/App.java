package in.ineuron;

import java.util.Scanner;

import in.ineuron.shape.circle;
import in.ineuron.shape.triangle;

/*1. Write a Java program that uses polymorphism by defining an interface called Shape
with methods to calculate the area and perimeter of a shape. Then create classes
that implement the Shape interface for different types of shapes, such as circles and
triangles.*/

public class App 
{
    public static void main( String[] args )
    {
    	// Rectangle area and parameter
    	Scanner sc = new Scanner(System.in);
    	System.out.println("***Enter detail for triangle***");
    	
    	System.out.println("Enter base of a triangle to calculate area");
    	double base=sc.nextDouble();
    	
    	System.out.println("Enter height of a triangle to calculate area");
    	double height=sc.nextDouble();
    	System.out.println("Enter first side length of a triangle to calculate perimeter");
    	double a=sc.nextDouble();
    	System.out.println("Enter second side length of a triangle to calculate perimeter");
    	double b=sc.nextDouble();
    	System.out.println("Enter third side length of a triangle to calculate perimeter");
    	double c=sc.nextDouble();
    	
    			
    			
    			triangle r = new triangle(base, height,a,b,c);

    			System.out.println("triangle - Area: " + r.area());
    			System.out.println("triangle - perimeter: " + r.perimeter());
    			
    			System.out.println("***Enter detail for circle***");		
    			System.out.println("Enter the radius of a circle  to calculate area and perimeter");
    	    	double radius=sc.nextDouble();
    	    	
    			circle d = new circle(radius);
    			System.out.println("Circle - Area: " + d.area());
    			System.out.println("Circle - perimeter: " + d.perimeter());
    }
}
